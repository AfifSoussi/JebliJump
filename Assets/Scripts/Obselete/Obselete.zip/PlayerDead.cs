using UnityEngine;
using System.Collections;

public class PlayerDead : MonoBehaviour {

public Transform last_respawn; // the current resspawn point
public bool  reset_camera_x = true;
public bool  reset_camera_y = true;
PlayerMovement playerMovement;
PlayerHealth playerHealth;
PlayerCamera playerCamera;



void Start (){
	playerMovement= GetComponent<PlayerMovement>() as PlayerMovement;
	playerHealth= GetComponent<PlayerHealth>() as PlayerHealth;
	playerCamera= GetComponent<PlayerCamera>() as PlayerCamera;
}

public IEnumerator respawn ( bool show_circle ,   float wait_for_fade ,   float wait_before  ){
	yield return new WaitForSeconds(wait_before);
	HelperFadeout helperFadeout= Camera.main.GetComponent<HelperFadeout>() as HelperFadeout;
	if(show_circle)
	{
		if(helperFadeout)
			helperFadeout.circle_fade("out");
		yield return new WaitForSeconds(wait_for_fade);
	}
	deadzone();
	if(show_circle)
	{
		if(helperFadeout)
			helperFadeout.circle_fade("in");
	}
}

public void deadzone() // same for landing into bottomless pit!
{

	if(last_respawn)
		transform.position = last_respawn.position;
	//else
	//	transform.position = start_pos;
		Vector3 tmp_pointer_position=playerCamera.camera_pointer.position;

	
	if(reset_camera_x)
	{
			tmp_pointer_position.x=transform.position.x+playerCamera.extra_position.x;
	}
	if(reset_camera_y)
	{
			tmp_pointer_position.x=transform.position.y+playerCamera.extra_position.y;
	}
	playerCamera.camera_pointer.position=tmp_pointer_position;

	playerMovement.current_speed=0;
	playerMovement.current_mode = playerStates.Idle;
	PlayerManager.Instance.DisableControls();
	playerHealth.health=playerHealth.max_health;
	playerHealth.lifes-=1;
	collider2D.isTrigger=false;
	rigidbody2D.isKinematic=false;
	PlayerPickups playerPickups= GetComponent<PlayerPickups>() as PlayerPickups;

}


void Update (){

	}


}