using UnityEngine;
using System.Collections;

public class PlayerUI : MonoBehaviour {


private PlayerHealth health_cs;
private PlayerCamera cam_cs;
private PlayerPickups pickups_cs;

void Start (){
	health_cs = GetComponent<PlayerHealth>() as PlayerHealth;
	cam_cs = GetComponent<PlayerCamera>() as PlayerCamera;
	pickups_cs = GetComponent<PlayerPickups>() as PlayerPickups;
}

void OnGUI (){
Mathf.Abs(cam_cs.camera_pointer.camera.pixelRect.y - cam_cs.camera_pointer.camera.pixelRect.height);
if(cam_cs.camera_pointer)
{
	GUI.Label( new Rect(10,30,100,20),"Health "+ health_cs.health + "/" + health_cs.max_health);
	GUI.Label( new Rect(10,10,100,90),"Lifes "+ health_cs.lifes );
}
		else
			print ("no camera pointer");

	
}
void Update (){
}
}