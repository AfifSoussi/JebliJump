using UnityEngine;
using System.Collections;

public class PlayerAttack : MonoBehaviour {


private PlayerMovement playerMovement;

public string attack_button = "Fire2";
public Transform spawn_attack;
public float spawn_distance = 1;
public bool  ignore_player_collision = true;
private Transform attack_pointer;
public int max_shots_in_scene = 2;
Quaternion rot;
Vector3 tmp_pos;

void Start (){
	playerMovement = GetComponent<PlayerMovement>() as PlayerMovement;
}

int check_for_shots_in_scene (){
	GameObject[] all_shots = GameObject.FindGameObjectsWithTag("Projectile");
	int shots = 0;
	foreach(GameObject shot in all_shots)
	{
		if(shot.GetComponent<HelperProjectile>())
		{
			if(shot.GetComponent<HelperProjectile>().owner == gameObject)
			{
				shots++;
			}
		}
	}
	return shots;
}

void Update (){
	if(Input.GetButtonDown(attack_button) && (check_for_shots_in_scene() < max_shots_in_scene || max_shots_in_scene == 0 ))
	{
	
	rot.eulerAngles = playerMovement.transform.eulerAngles;
			//tmp_pos.x=playerMovement.transform.position.x+spawn_distance*playerMovement.playerDirection;
			//tmp_pos.y=playerMovement.transform.position.y;
			//tmp_pos.z=0;

		attack_pointer = Instantiate (spawn_attack,  tmp_pos,rot) as Transform;
		if(attack_pointer.GetComponent<HelperProjectile>())
		{
			attack_pointer.GetComponent<HelperProjectile>().owner = gameObject;
		}
		if(ignore_player_collision)
		{
			//Physics2D.IgnoreCollision(attack_pointer.collider,collider);

		}
	}
}
}