using UnityEngine;
using System.Collections;

public class AttackFireball : MonoBehaviour {
public float direction = 1;

public float bounce = 3;
public float speed = 3;
public float damage = 50;
private float lifespan = 4f;
Vector2 tmp_velocity;
//CircleCollider2D FireballCollider;

void OnCollisionStay2D ( Collision2D collisionInfo  ){
	if(collisionInfo.transform.tag!="Projectile")
	{
	    foreach(ContactPoint2D contact in collisionInfo.contacts) {
				if(transform.position.y-contact.point.y<0.8f)
				{
					tmp_velocity=rigidbody2D.velocity;
					tmp_velocity.y=bounce;
					rigidbody2D.velocity=tmp_velocity;
				}
				if(transform.position.x-contact.point.x<-0.3f)
				{
					direction=-1;
				}
				if(transform.position.x-contact.point.x>0.3f)
				{
					direction=1;
				}
	    }
	}
    if(collisionInfo.transform.tag=="Enemy")
    {
    	collisionInfo.transform.SendMessage("apply_damage", damage);
		print ("i hit an enemy");
    	Destroy(gameObject);
    }
		/*
	if(collisionInfo.transform.tag=="Player")
		{
			FireballCollider.isTrigger=true;
		}
	else
			print ("ff");
		*/
}
void Update (){
		tmp_velocity=rigidbody2D.velocity;
		tmp_velocity.x=speed*direction;
		rigidbody2D.velocity=tmp_velocity;
}

IEnumerator destroyFireball() {
		yield return new WaitForSeconds(lifespan);
		Destroy(gameObject);

	}

void Start (){
	tag = "Projectile";
	if(transform.eulerAngles.y==0 || transform.eulerAngles.y==90)
	{
		direction=1;
	}
	else
	{
		direction=-1;
	}
		//FireballCollider = GetComponent<CircleCollider2D>() as CircleCollider2D;
		StartCoroutine((destroyFireball()));

}
}