using UnityEngine;
using System.Collections;

public class TriggerGoal : MonoBehaviour {

public string load_level = "level_name";
public float wait_till_fadeout = 2;
public float wait_till_lvl_change = 4;
private bool  already_triggered = false;
IEnumerator OnTriggerEnter2D ( Collider2D other  ){
	if(other.transform.tag == "Player" && !already_triggered)
	{
		PlayerMovement playerMovement= other.GetComponent<PlayerMovement>() as PlayerMovement;
		//stop the player and play goal animation
		PlayerManager.Instance.DisableControls();
		playerMovement.current_mode=playerStates.Idle;
		playerMovement.movement_direction=0;
		playerMovement.current_speed=0;playerMovement.last_velocity=Vector2.zero;
		playerMovement.anim.CrossFade("Goal",0f);

		already_triggered=true;

	yield return new WaitForSeconds(wait_till_fadeout);

	HelperFadeout helperFadeout= Camera.main.GetComponent<HelperFadeout>() as HelperFadeout;
	if(helperFadeout)
		StartCoroutine(helperFadeout.circle_fade("out"));

	yield return new WaitForSeconds(wait_till_lvl_change-wait_till_fadeout);
	Application.LoadLevel(load_level);
	}
	


}

}