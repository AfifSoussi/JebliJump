using UnityEngine;
using System.Collections;

public class HelperPlatform : MonoBehaviour {

private Vector3 old_pos;
bool  move = false;
float speed = 1;
float time_shift = 0.0f;
Vector3 move_by=Vector3.zero;

void Start (){
	old_pos = transform.position;
	tag = "platform";
}

void LateUpdate (){
		if(move)
			transform.position = Vector3.Lerp(old_pos,old_pos+move_by,(Mathf.Sin((Time.time+time_shift)*speed)+1)/2);
	transform.eulerAngles = Vector3.zero;
}
}