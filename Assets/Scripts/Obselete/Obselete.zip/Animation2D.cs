using UnityEngine;
using System.Collections;

public class Animation2D : MonoBehaviour {

	public class ani // container for an animation
{
		public string name = "Ani Name"; // name of the animation
		public Texture2D[] graphics; // graphic array
		public float speed = 1.0f; // 
		public bool  loop = false;
		public string play_after = "";
}

	public string start_animation = "";
	public ani[] animations;
	public Renderer renderer_pointer; // the renderer we want to modify

	public int current_animation = -1; // the array-id of the current animation
private float current_frame = 0;
	public int return_ani_ID( string name  ) // returns the array ID of a name
{
	for(int i = 0; i < animations.Length; i++) // loop over the array
	{
		if(animations[i].name == name)
			return i; // return the ID
	}
	return -1; // -1 if we can't find the animation
}

	public void play_animation( string name  ) // plays an animation by name
{
	int ID = return_ani_ID(name);
	if(ID==-1)  // invalid animation name
	{
		Debug.LogError("Can't find animation with name " + name);
		return;
	}
	current_frame=0; // reset the framecounter
	current_animation = ID; // set the new ID
}
void Start (){
	if(!renderer_pointer) // no renderer found? then use the renderer of this object
		if(renderer)renderer_pointer = renderer;
		else Debug.LogError("No renderer found. Please fill the 'renderer_pointer' variable"); // but if this object has no renderer then ERROR
	if(start_animation.Length>0) // there is a start animation? play it!
	{
		play_animation(start_animation);
	}
}

public bool isPlaying (){
	if(current_frame==animations[current_animation].graphics.Length-1)
	{
		return false;
	}
	else
	{
		return true;
	}
}

void Update (){

	if(current_animation ==-1) return; // nothing to animate? then stop here!
	current_frame+=animations[current_animation].speed*Time.deltaTime; // go trough the frames by speed
	if(animations[current_animation].loop) current_frame = current_frame % animations[current_animation].graphics.Length; // a looping animation? start at the beginning at the end
	else 
	{
		current_frame = Mathf.Min(current_frame,animations[current_animation].graphics.Length-1); // don't loop? stop at the end
		if(animations[current_animation].play_after.Length>0 && current_frame==animations[current_animation].graphics.Length-1)
		{
			play_animation(animations[current_animation].play_after);
		}
	}
	
	renderer_pointer.material.mainTexture = animations[current_animation].graphics[1]; // set the new texture
	
}
}