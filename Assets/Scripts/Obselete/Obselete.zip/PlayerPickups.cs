﻿using UnityEngine;
using System.Collections;

public class PlayerPickups : MonoBehaviour {

public AudioClip CoinCollect; 				
private PlayerHealth health_cs;
public Animator anim;

public GameObject animateobject;

	public int give_health = 50;
	public int give_coin = 1;

	// Use this for initialization
	void Start () {
		health_cs = GetComponent<PlayerHealth>() as PlayerHealth;
		anim= GetComponent<Animator>();
	}

void OnTriggerEnter2D ( Collider2D collisionInfo  ){

	if (collisionInfo.tag == "Coin")
		{
			collisionInfo.renderer.enabled = false;
			collisionInfo.collider2D.enabled = false;
			audio.PlayOneShot(CoinCollect);
			LevelManager.Instance.CoinGathered();
			//Destroy(collisionInfo.gameObject);
		}
	if (collisionInfo.tag == "Health")
		{
			//collisionInfo.renderer.enabled = false;
			collisionInfo.collider2D.enabled = false;
			audio.PlayOneShot(CoinCollect);
		//	health_cs.health+=give_health;
			//Destroy(collisionInfo.gameObject);
		}


}
	// Update is called once per frame
	void Update () {
	
	}

	void OnApplicationQuit(){
	
	
	}
}
