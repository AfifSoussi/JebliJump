﻿using UnityEngine;
using System.Collections;

public class TriggerPickupItem : MonoBehaviour {
	
	public float give_health = 50;
	public bool  kill_parent = true;
	void OnTriggerEnter2D ( Collider2D collisionInfo  ){
		print ("pickup health");
		if(collisionInfo.transform.tag=="Player")
		{
			if(collisionInfo.transform.GetComponent<PlayerHealth>())
			{
				collisionInfo.transform.GetComponent<PlayerHealth>().health+=give_health;
			}
			if(kill_parent)
				Destroy(transform.parent.gameObject);
			else
				Destroy(gameObject);
		}
	}
	
}