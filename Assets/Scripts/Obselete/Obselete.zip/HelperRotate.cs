using UnityEngine;
using System.Collections;

public class HelperRotate : MonoBehaviour {

public Vector3 rotate;
void Update (){
	if(!rigidbody)
		transform.Rotate(rotate * Time.deltaTime);
}

void FixedUpdate (){
	if(rigidbody)
	{
		Quaternion deltaRotation = Quaternion.Euler(rotate * Time.deltaTime);
		rigidbody.MoveRotation(rigidbody.rotation * deltaRotation);
	}
}
}