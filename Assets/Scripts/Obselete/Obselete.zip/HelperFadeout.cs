using UnityEngine;
using System.Collections;

public class HelperFadeout : MonoBehaviour {

public float circle_timer;

public  Texture2D color_image;
public Texture2D circle_image;
public float speed = 5;
public Transform target;

private string public_fader;
void Start (){
	if(!target)
			target = GameObject.FindWithTag("Player").transform;
		else
			print ("no target ! ");	
	StartCoroutine(circle_fade("in"));
	if(tag!="MainCamera")
		Debug.LogError("Please attach the Helper Fadeout to the Camera tagged 'MainCamera'");
}
public IEnumerator circle_fade ( string fader  ){
		if(fader=="in")
		{
		public_fader="in";
		while(circle_timer<3001)
		{
			circle_timer+=((speed*100)*Time.deltaTime)+circle_timer/50;
			if(public_fader=="out") yield break;
			yield return 0;
		}	
		circle_timer=3001;
	}
	if(fader=="out")
	{
		public_fader="out";
		circle_timer=4000;
		while(circle_timer>-1)
		{
			if(Camera.main.audio)if(Camera.main.audio.isPlaying)Camera.main.audio.volume=Mathf.Min(0.4f,circle_timer/5000);
			circle_timer-=(((1+speed)*100)*Time.deltaTime)+circle_timer/50;
			if(public_fader=="in") yield break;
			yield return 0;
		}	
		circle_timer=-1;
	}
}

void OnGUI (){
GUI.depth=1;
	Vector3 player_pos= Camera.main.WorldToScreenPoint(target.position);
	if(circle_timer<3000)
		{
	GUI.DrawTexture( new Rect(player_pos.x-circle_timer/2-2000,(Camera.main.pixelHeight-player_pos.y)-circle_timer/2-4000,4000,4000),color_image);
	GUI.DrawTexture( new Rect(player_pos.x-circle_timer/2-4000,(Camera.main.pixelHeight-player_pos.y)-circle_timer/2-1000,4000,4000),color_image);
	GUI.DrawTexture( new Rect(player_pos.x+circle_timer/2,(Camera.main.pixelHeight-player_pos.y)-circle_timer/2-2000,4000,4000),color_image);
	GUI.DrawTexture( new Rect(player_pos.x-circle_timer/2,(Camera.main.pixelHeight-player_pos.y)+circle_timer/2,4000,4000),color_image);
	GUI.DrawTexture( new Rect(player_pos.x-circle_timer/2,(Camera.main.pixelHeight-player_pos.y)-circle_timer/2,circle_timer,circle_timer),circle_image);
	}
}
}