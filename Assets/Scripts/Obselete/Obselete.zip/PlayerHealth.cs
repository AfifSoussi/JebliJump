using UnityEngine;
using System.Collections;

public class PlayerHealth : MonoBehaviour {

public float max_health = 100;
public float health = 100;
public int max_lifes = 9;
public int lifes = 3;
public float recover_time = 3;
public  bool  transparent_while_recover = true;
private Color old_Color;
private float recover_time_count = 0;
private PlayerMovement playerMovement;
private PlayerDead playerDead;
public bool  passable_on_death = true;
public string animation_dead = "Dead";
public SpriteRenderer spriteRenderer;


public bool  circle_fadeout = true;
public float wait_for_respawn = 1;
public float wait_for_fade = 2;


public void apply_damage ( float damage  ){
	if(recover_time_count==0 )
	{
		if(transform.renderer)
		{
			//playerMovement.player_graphic_pointer.renderer.material.shader = Shader.Find( "Transparent/Diffuse" );
			//playerMovement.player_graphic_pointer.renderer.material.SetColor("_Color",Color(1,1,1,0.5f));
				spriteRenderer.color=Color.red;		
		}
			else
				print ("no player in scene");

		playerMovement.current_mode = playerStates.Hit;
		print ("i got hit !! :( ");
		health-=damage;
		recover_time_count = recover_time;
	}
}

void Start (){
	playerMovement = GetComponent<PlayerMovement>() as PlayerMovement;
	playerDead = GetComponent<PlayerDead>() as PlayerDead;
	spriteRenderer= GetComponent<SpriteRenderer>() as SpriteRenderer;

	if(transform.renderer)
		old_Color = spriteRenderer.color;
}
	

public void LateUpdate (){

	
	health=Mathf.Clamp(health,0,max_health);
	lifes=Mathf.Clamp(lifes,0,max_lifes);
	if(recover_time_count==0)
	{
				if(spriteRenderer.color!=old_Color)
			{
					spriteRenderer.color=old_Color;
			}
	}
	else
	{
		recover_time_count=Mathf.Max(0,recover_time_count-Time.deltaTime);
	}


	if(health<=0 && playerMovement.current_mode != playerStates.Dead)
	{
		playerMovement.current_mode = playerStates.Dead;
		PlayerManager.Instance.DisableControls();
		if(passable_on_death)
		{
			collider2D.isTrigger=true;
			rigidbody2D.isKinematic=true;
		}
		playerDead.respawn(circle_fadeout,wait_for_fade,wait_for_respawn);
	}
}
}