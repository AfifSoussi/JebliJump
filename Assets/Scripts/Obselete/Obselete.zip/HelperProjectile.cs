using UnityEngine;
using System.Collections;

public class HelperProjectile : MonoBehaviour {
public GameObject owner;

}