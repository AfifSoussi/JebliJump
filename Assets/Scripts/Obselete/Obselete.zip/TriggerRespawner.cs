using UnityEngine;
using System.Collections;

public class TriggerRespawner : MonoBehaviour {

void Start (){
	gameObject.layer = 2;
	if(renderer)renderer.enabled=false;
}
void OnTriggerEnter2D ( Collider2D other  ){
	if(other.transform.tag == "Player")
	{
		PlayerDead playerDead= other.GetComponent<PlayerDead>() as PlayerDead;
		playerDead.last_respawn = transform;
	}
}
}